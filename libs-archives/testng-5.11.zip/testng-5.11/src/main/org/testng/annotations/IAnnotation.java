package org.testng.annotations;

/**
 * The parent interface for all the annotations.
 * 
 * Created on Dec 20, 2005
 * 
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 */
public interface IAnnotation {
}

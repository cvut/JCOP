package org.testng.internal.annotations;

public interface IBeforeSuite extends IBaseBeforeAfter {

}

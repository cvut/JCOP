package org.testng.internal.annotations;

import org.testng.annotations.IObjectFactoryAnnotation;

/**
 * The internal representation of @ObjectFactory
 * @author Hani
 */
public class ObjectFactoryAnnotation extends BaseAnnotation implements IObjectFactoryAnnotation
{}
